FactoryGirl.define do
  factory :profile do
    
  end
end
