FactoryGirl.define do
  factory :user do
    email "MyString"
    password_digest "MyString"
  end
end
