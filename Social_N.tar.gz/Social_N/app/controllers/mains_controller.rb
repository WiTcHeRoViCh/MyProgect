class MainsController < ApplicationController

  def index

  end	

end	